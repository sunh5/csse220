import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;
import java.util.ArrayList;

public abstract class Element implements Temporal, Drawable {
	private Point2D drawPoint;
	private GameWorld world;
	private static ArrayList<Double> upperWallEdge;
	protected Rectangle2D.Double box;
	/**
	 * Constructs an object whose upper left point is at the given point in the
	 * given world. Think of the obejct as a square, this is also the point where
	 * object starts to be drawn.
	 * 
	 * @param world
	 * @param drawPoint
	 */

	public Element(GameWorld world, Point2D drawPoint) {
		this.world = world;
		this.drawPoint = drawPoint;
		this.box = new Rectangle2D.Double(getDrawPoint().getX(),getDrawPoint().getY(),getWidth(),getWidth());
//		this.box=new Rectangle2D.Double(drawPoint);
//		this.upperWallEdge = new ArrayList<Double>();
	}
	// -------------------------------------------------------------------------
		// Drawable interface (partial implementation, subclasses must help)
	
	
	public abstract void collideWith(Element other);
	
	public boolean collideWithWall(Wall wall){

		if(this.box.intersects(wall.box)){
//			this.world.isFalling = false;
			return false;
		}
		return true;
	}
	public abstract void collideWithMonster(Monster monster);
	public abstract void collideWithHero(Hero hero);
	
	
	
	@Override
	public Shape getShape() {
		double x = getDrawPoint().getX();
		double y = getDrawPoint().getY();
		
		double size = getWidth();
//		this.box = new Rectangle2D.Double(x,y,size,size);
		return new Rectangle2D.Double(x,y,size,size);
	}
	public double getYaxis() {
		double y = getDrawPoint().getY();
		return y;
	}
	public double getXaxis() {
		double x = getDrawPoint().getX();
		return x;
	}
	public Point2D getDrawPoint() {
		return this.drawPoint;
	}
	public void setDrawPoint(Point2D newPoint) {
		this.drawPoint = newPoint;
	}
	// Temporal interface

	@Override
	public void timePassed() {
		updateSize();
		updateColor();
		updatePosition();
	}

	@Override
	public void die() {
		// not yet implemented
	}

	@Override
	public boolean getIsPaused() {
		// not yet implemented
		return false;
	}

	@Override
	public void setIsPaused(boolean isPaused) {
		// not yet implemented
	}
	
	public abstract double getWidth();
	
	public abstract void updatePosition();
	public abstract void updateSize();
	public abstract void updateColor();

	

}
