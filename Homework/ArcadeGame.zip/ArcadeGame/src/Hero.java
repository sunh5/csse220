import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;

public class Hero extends Element {

	private Color color;
	private double width;
	private GameWorld world;
	private double dx;
	private double dy;
	private Point2D point;
	private int heroXaxis;// = (int)this.world.heros.get(0).getXaxis();
	private int heroYaxis;// = (int)this.world.heros.get(0).getYaxis();

	public Hero(GameWorld world, Point2D drawPoint) {
		super(world, drawPoint);
		this.world = world;
		this.color = Color.blue;
		this.width = 40.0;
		
	}

	@Override
	public void timePassed() {
		updatePosition();

	}

	@Override
	public void die() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setIsPaused(boolean isPaused) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean getIsPaused() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Color getColor() {
		// TODO Auto-generated method stub
		return this.color;
	}

	@Override
	public double getWidth() {
		// TODO Auto-generated method stub
		return this.width;
	}


	@Override
	public void updatePosition() {
		


		if (this.world.isMovingLeft == this.canFly()) {
			System.out.println("left:  "+ this.canFly());
			this.moveLeft();
		} if (this.world.isMovingRight == this.canFly()) {
			System.out.println("right:  "+ this.canFly());
			this.moveRight();
		}
		if (this.world.isFlying == this.canFly()) {
			System.out.println("fly:  "+ this.canFly());
			this.fly();
		} if (this.world.isFalling == this.canFly()) {
			System.out.println("fall:  "+ this.canFly());
			this.fall();
		}
	}

	@Override
	public void updateSize() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateColor() {
		// TODO Auto-generated method stub

	}

	public void moveLeft() {

		double dx = this.getDrawPoint().getX() - 1;
		if (dx <= 0) dx = 0;
		Point2D point = new Point2D.Double(dx, this.getDrawPoint().getY());
		this.setDrawPoint(point);
	}

	public void moveRight() {
		double dx = this.getDrawPoint().getX() + 1;
		if (dx+40 >= 1000.0) dx = 960;
		Point2D point = new Point2D.Double(dx, this.getDrawPoint().getY());
		this.setDrawPoint(point);
	}

	public void fly() {
		double dy = this.getDrawPoint().getY() - 1;
		if (dy <= 0.0) dy = 0;
		Point2D point = new Point2D.Double(this.getDrawPoint().getX(), dy);
		this.setDrawPoint(point);
	}

	public void fall() {
		double dy = this.getDrawPoint().getY() + 1;
		if (dy+40 >= 800.0) dy = 760;
		Point2D point = new Point2D.Double(this.getDrawPoint().getX(), dy);
		this.setDrawPoint(point);
	}

	public boolean canFly() {
		for (int i = 0; i < this.world.xWallEdge.size(); i++) {
//			System.out.println(i);
			Rectangle rect = new Rectangle(this.world.xWallEdge.get(i), this.world.yWallEdge.get(i), 50, 50);
			Rectangle hero = new Rectangle((int)this.world.heros.get(0).getXaxis(), (int)this.world.heros.get(0).getYaxis(), 40, 40);
//			System.out.println("wall x  "+this.world.xWallEdge.get(i));
			if (rect.intersects(hero)){             
				return false;
			}
//			if (rect.contains(this.heroXaxis+40,this.heroYaxis)) {
//				return false;
//			}
//			if (rect.contains(this.heroXaxis,this.heroYaxis+40)) {
//				return false;
//			}
//			if (rect.contains(this.heroXaxis+41,this.heroYaxis+40)) {
//				return false;
//			}
//			if ((int)this.world.heros.get(0).getXaxis() == 0) 
		}
		return true;
		
	}

	@Override
	public void collideWith(Element other) {
		// TODO Auto-generated method stub
		other.collideWith(this);
	}

	@Override
	public void collideWithMonster(Monster monster) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void collideWithHero(Hero hero) {
		// TODO Auto-generated method stub
		
	}

	

}
