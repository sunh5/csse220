
public interface Temporal {
	void timePassed();
	void die();
}
