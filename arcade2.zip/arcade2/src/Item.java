
public class Item {

	public Item() {
		// TODO Auto-generated constructor stub.
	}

}
