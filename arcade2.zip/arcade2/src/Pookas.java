public class Pookas extends Monster{

	public Pookas(int startx, int starty, GameWorld world) {
		/*
		 * Pooka with simple movement and cannot fire, directly extends from monster
		 */
		super(startx, starty, world);
//		this.imageName="images/Pookas.png";
	}

}
