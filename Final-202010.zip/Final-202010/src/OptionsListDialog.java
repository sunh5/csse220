

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class OptionsListDialog {

	ArrayList<String> options;
	JLabel label;
	ActionListener resultListener;
	
	public OptionsListDialog() {
		options = new ArrayList<String>();
	}
	
	public void addOption(String option) {
		options.add(option);
	}
	
	public void setActionListener(ActionListener resultListener) {
		this.resultListener = resultListener; 
	}
	
	public String getChoice() {
		return label.getText().substring(16);
	}
	
	public void showWindow() {
		JFrame frame = new JFrame("Choose Wisely!");
		
		label = new JLabel("Current choice: " + options.get(0));
		JButton ok = new JButton("Ok");
		ok.addActionListener(resultListener);		
		frame.add(label, BorderLayout.NORTH);
		frame.add(ok, BorderLayout.SOUTH);
		
		
		JList list = new JList(options.toArray());
		list.setBackground(Color.LIGHT_GRAY);
		list.addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent e) {
				label.setText("Current choice: " +  options.get(list.getSelectedIndex()));
				
			}
		});
		
		frame.add(list);
		
		frame.pack();
		frame.setVisible(true);
	}
	
}
