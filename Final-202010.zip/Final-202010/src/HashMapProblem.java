

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class HashMapProblem {
	
	/* TODO
	 * 
	 * Imagine a hashmap that represents dependencies between
	 * servers.  So if the pair "A" -> "B" is in the map, that
	 * means that A depends on B.  In this architecture, a server
	 * can only depend on one other server at most (and maybe depends 
	 * on none, in which case it's not in the map).  You can also
	 * assume there are no dependency cycles.
	 * 
	 * Our function computes the length of the longest dependency 
	 * chain.
	 * 
	 * So if the map looks like this:
	 * 
	 * C -> D
	 * A -> B
	 * B -> C
	 * E -> F
	 * 
	 * The longest dependency chain is A->B->C->D so they function will
	 * return 4.
	 * 
	 * Another example:
	 * 
	 * A -> B
	 * C -> D
	 * E -> F
	 * 
	 * Longest dependency chain is 2.
	 * 
	 * An empty map is considered to have a dependency chain of 1, because surely 
	 * there is a server somewhere right? 
	 */
	public static int longestChain(HashMap<String, String> map) {
		
		return 0;
	}
}
