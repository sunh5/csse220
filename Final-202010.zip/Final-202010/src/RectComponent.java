

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComponent;

/**
 * A component that contains balls.
 * 
 * Modify this class as you need
 * 
 * 
 */
public class RectComponent extends JComponent {

	private ArrayList<Rect> rects;	
	
	//This constructor initializes a single box
	public RectComponent() {
		rects = new ArrayList<>();
	}
	
	//This method should draw anything considered to be part of the Component
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.drawString("Part 1", 30, 30);
		g2.drawString("Part 2", 30, 190);
		g2.drawString("Part 3 & 4", 30, 330);
		
		for(Rect b : rects) {
			b.draw(g2);
		}
	}

	public void addRect(Rect b) {
		rects.add(b);
		
	}

}
